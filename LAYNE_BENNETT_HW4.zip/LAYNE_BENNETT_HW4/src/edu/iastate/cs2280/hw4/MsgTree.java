/**
 * @author Layne Bennett
 */

package edu.iastate.cs2280.hw4;

import java.util.Scanner;
import java.io.File;
import java.io.FileNotFoundException;
/**
 * Binary search tree for storing the character payloadChar on each node, 
 * with the desired characters for printing on the leaves
 * 
 * Left branches are represented by a 0, right is a 1
 */
public class MsgTree {
	//Character on each node of tree
	public char payloadChar;
	//Node to left of parent
	public MsgTree left;
	//Node to right of parent
	public MsgTree right;
	//Index of the current character being looked at in the encoding string
	private static int staticCharIdx = 0;
	//Number of total characters in the encoded message
	private static double charNum = 0;
	//Total number of bits in the encoded message
	private static double totalBit = 0;
	
	

/**Constructor building the tree from a string
 * by parsing encodingString
 * 
 * 
 * @param encodingString
 * The input string that represents a preorder traversal of a tree
 * 
 */
	public MsgTree(String encodingString) {
		
		//reads one character at a time and increments it with each MsgTree
		payloadChar = encodingString.charAt(staticCharIdx);
		
		staticCharIdx++;
		
		//if not a leaf, create two children below, starting from the left
		if (payloadChar == '^') {
			left = new MsgTree(encodingString);
			right = new MsgTree(encodingString);
		} else {//is a leaf, so children are null
			left = null;
			right = null;
		}
	}

/**Constructor for a single node with null children
 * 
 * 
 * @param payloadChar
 * one character input
 */
	public MsgTree(char payloadChar) {
		this.left = null;
		this.right = null;
		this.payloadChar = payloadChar;
	}

/**method to print characters and their binary codes
 * 
 * @param root 
 * the current node being viewed in the iteration
 * 
 * @param code 
 * the string of 0s and 1s being created for each character/leaf
 */
	public static void printCodes(MsgTree root, String code) {

		//if null input, return nothing
		if (root == null) {
			return;
		}
		
		//if the character is not a leaf, add to the codes for left and right children
		if (root.payloadChar == '^') {
			printCodes(root.left, code + "0");
			printCodes(root.right, code + "1");
		} else {//if a leaf, print out the finished code of the leaf
			System.out.println("   " + root.payloadChar + "      " + code);

		}
	}

	/**
	 * Decodes the given string msg into characters using the
	 * codes MsgTree to traverse through
	 * 
	 * @param codes
	 * the associated codes with each character stored in a BST
	 * 
	 * @param msg
	 * coded message as a string
	 */
	public void decode(MsgTree codes, String msg) {

		//character for the current node
		char out = codes.payloadChar;

		//temporary search tree for traversing through
		MsgTree temp = codes;

		//for loop to scan message character by character
		for (int i = 0; i < msg.length(); i++) {
			
			//goes left or right depending on the characters in the message.
			if (msg.charAt(i) == '0') {
				temp = temp.left;
				totalBit++;
			} else {
				temp = temp.right;
				totalBit++;
			}
			
			//update current character of node
			out = temp.payloadChar;
			
			//if it is a leaf, print the character with the exception of '~' 
			//which represents a newline as a single character
			if (out != '^') {
				if (out == '~') {
					System.out.println();
					charNum++;//updates the total character count
				} else {
					System.out.print(out);
					charNum++;//total character count 
				}
				temp = codes;//reset tree to root
			}

		}

		System.out.println();
	}

	/**
	 * Reads the given file from the filepath, turns it into two separate strings,
	 * and prints all information including character codes, the encoded message, 
	 * and the statistics
	 * 
	 * @param filePath
	 * filepath of the arch file the user inputs
	 */
	public static void readFile(String filePath) {
		try {

			File file = new File(filePath);

			Scanner scnr = new Scanner(file);

			String encoding = "";//encoding scheme as string
			String code = "";//bit code as a string

			//reads first line which is encoding scheme
			if (scnr.hasNextLine()) {
				encoding = encoding + scnr.nextLine();
			}
			
			//reads second line which could be either 
			//encoding scheme or binary code
			if (scnr.hasNextLine()) {

				String temp = scnr.nextLine();
				
				int i;
				
				//scans to see if the line is all binary
				for (i = 0; i < temp.length(); i++) {
					if (temp.charAt(i) != '1' && temp.charAt(i)!= '0') {
						break;
					}
				}
				//if line is part of the encoding scheme, that
				//means the encoding scheme needs a newline char
				if(i<temp.length()-1) {
					encoding = encoding+"~"+temp;
				}else {//else it's binary and add it to code string
					code = temp;
				}

			}
			
			//adds rest of lines to binary code string
			while(scnr.hasNextLine()) {
				code = code+scnr.nextLine();
			}

			scnr.close();
			
			//bunch of printing
			MsgTree tree = new MsgTree(encoding);
			MsgTree.printCodes(tree, "");
			
			System.out.println();
			System.out.println("MESSAGE: ");
			
			tree.decode(tree, code);
			
			System.out.println();
			System.out.println("STATISTICS:");
			
			System.out.println("Avg bits/char: "+totalBit/charNum);
			System.out.println("Total characters: "+charNum);
			System.out.println("Space savings: "+100*(1-(totalBit/(charNum*16)))+"%");
			
			

		} catch (FileNotFoundException e) {
			System.out.println("File not found: " + filePath);

			
		}

	}
	
	/**
	 * Prompts user for arch filepath, 
	 * then should print out the encoded message
	 * @param args
	 */
	public static void main(String[] args) {
		
		//user prompting for filepath
		System.out.println("Filepath?");
		
		Scanner scnr = new Scanner(System.in);
		
		String input = scnr.nextLine();
		
		scnr.close();
		
		
		
		System.out.println("character   code");
		System.out.println("-------------------------");
		
		readFile(input);
	}

}
