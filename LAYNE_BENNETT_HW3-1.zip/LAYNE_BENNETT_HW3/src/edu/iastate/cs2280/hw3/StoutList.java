package edu.iastate.cs2280.hw3;

/**
 *  
 * @author Layne Bennett
 *
 */

import java.util.AbstractSequentialList;
//import java.util.Arrays;
//import java.util.Comparator;
import java.util.Iterator;
import java.util.ListIterator;
import java.util.NoSuchElementException;

/**
 * Implementation of the list interface based on linked nodes that store
 * multiple items per node. Rules for adding and removing elements ensure that
 * each node (except possibly the last one) is at least half full.
 */
public class StoutList<E extends Comparable<? super E>> extends AbstractSequentialList<E> {
	/**
	 * Default number of elements that may be stored in each node.
	 */
	private static final int DEFAULT_NODESIZE = 4;

	/**
	 * Number of elements that can be stored in each node.
	 */
	private final int nodeSize;

	/**
	 * Dummy node for head. It should be private but set to public here only for
	 * grading purpose. In practice, you should always make the head of a linked
	 * list a private instance variable.
	 */
	public Node head;

	/**
	 * Dummy node for tail.
	 */
	private Node tail;

	/**
	 * Number of elements in the list.
	 */
	private int size;

	/**
	 * Constructs an empty list with the default node size.
	 */
	public StoutList() {
		this(DEFAULT_NODESIZE);
	}

	/**
	 * Constructs an empty list with the given node size.
	 * 
	 * @param nodeSize number of elements that may be stored in each node, must be
	 *                 an even number
	 */
	public StoutList(int nodeSize) {
		
		
		
		if (nodeSize <= 0 || nodeSize % 2 != 0)
			throw new IllegalArgumentException();

		// dummy nodes
		head = new Node();
		tail = new Node();
		head.next = tail;
		tail.previous = head;
		this.nodeSize = nodeSize;
		size = 0;
	}

	/**
	 * Constructor for grading only. Fully implemented.
	 * 
	 * @param head
	 * @param tail
	 * @param nodeSize
	 * @param size
	 */
	public StoutList(Node head, Node tail, int nodeSize, int size) {
		this.head = head;
		this.tail = tail;
		this.nodeSize = nodeSize;
		this.size = size;
	}

	/**
	 * returns size of list
	 * 
	 * @return size
	 */
	@Override
	public int size() {
		return size;
	}

	/**
	 * Adds a new item in a Node according to add rules.
	 */
	@Override
	public boolean add(E item) {

		if (item == null) {
			throw new NullPointerException();
		}
		// if the list is empty or the last node before tail is full, make a new node
		if (size == 0 || (tail.previous.count >= (nodeSize))) {
			Node temp = new Node();

			temp.previous = tail.previous;
			temp.next = tail;
			tail.previous.next = temp;
			tail.previous = temp;

			temp.addItem(item);

		}
		// else insert into node before tail
		else {
			tail.previous.addItem(tail.previous.count, item);

		}
		++size;
		return true;
	}

	/**
	 * Adds a new item at the specified position
	 */
	@Override
	public void add(int pos, E item) {
		
		//null node catch
		if (item == null) {
			throw new NullPointerException();
		}
		
		//out of bounds
		if (pos < 0 || pos > size)

			throw new IndexOutOfBoundsException();
		
		//empty list
		if (head.next == tail) {
			add(item);

		}

		
		//find offset within node
		NodeInfo nodeInfo = find(pos);
		Node current = nodeInfo.node;
		int offset = nodeInfo.offset;
		
		
		//add according to rules
		if (offset == 0 && current.previous.count < nodeSize) {
			current.previous.addItem(current.previous.count, item);
			
		} else if (current.next == null && current.previous.count == nodeSize) {
			Node temp = new Node();

			temp.addItem(item);

			temp.previous = tail.previous;
			temp.next = tail;
			tail.previous.next = temp;
			tail.previous = temp;

		} else if (current.count < nodeSize) {
			current.addItem(offset, item);

		} else if (current.count >= nodeSize) {

			Node temp = new Node();

			temp.previous = current;
			temp.next = current.next;
			current.next.previous = temp;
			current.next = temp;

			for (int i = (nodeSize / 2); i < nodeSize; i++) {
				temp.addItem(current.data[i]);
			}
			for (int i = (nodeSize / 2); i < nodeSize; i++) {
				current.removeItem(i);
			}
			if (offset <= nodeSize / 2) {
				current.addItem(offset, item);
			} else {
				temp.addItem(offset - (nodeSize / 2), item);
			}

		}
		++size;
	}
	
	/**
	 * remove an element from a specified position and return it
	 * @return Object E
	 */
	@Override
	public E remove(int pos) {

		if (pos < 0 || pos > size)
			throw new IndexOutOfBoundsException();
		
		//find offset of node
		NodeInfo nodeInfo = find(pos);
		Node current = nodeInfo.node;
		int offset = nodeInfo.offset;

		E ret = current.data[offset];
		
		//remove according to remove rules
		if (current.count == 1 && current.next == tail) {

			current.previous.next = current.next;
			current.next.previous = current.previous;
		} else if (current.next == tail || current.count > nodeSize / 2) {
			current.removeItem(offset);
		} else if (current.next.count > nodeSize / 2) {
			current.removeItem(offset);
			current.addItem(current.next.data[0]);
			current.next.removeItem(0);
		} else {
			current.removeItem(offset);
			for (int i = 0; i < current.next.count; i++) {
				current.addItem(current.next.data[i]);
			}
			current.next = current.next.next;
			current.next.previous = current;
		}
		size--;
		return ret;
	}

	/**
	 * Sort all elements in the stout list in the NON-DECREASING order. You may do
	 * the following. Traverse the list and copy its elements into an array,
	 * deleting every visited node along the way. Then, sort the array by calling
	 * the insertionSort() method. (Note that sorting efficiency is not a concern
	 * for this project.) Finally, copy all elements from the array back to the
	 * stout list, creating new nodes for storage. After sorting, all nodes but
	 * (possibly) the last one must be full of elements.
	 * 
	 * Comparator<E> must have been implemented for calling insertionSort().
	 */
	public void sort() {

		E[] sortedList = (E[]) new Comparable[size];

		int tempIndex = 0;
		Node temp = head.next;
		while (temp != tail) {
			for (int i = 0; i < temp.count; i++) {
				sortedList[tempIndex] = temp.data[i];
				tempIndex++;
			}
			temp = temp.next;
		}

		insertionSort(sortedList);

		head.next = tail;
		tail.previous = head;

		size = 0;
		for (int i = 0; i < sortedList.length; i++) {
			add(sortedList[i]);
		}

	}

	/**
	 * Sort all elements in the stout list in the NON-INCREASING order. Call the
	 * bubbleSort() method. After sorting, all but (possibly) the last nodes must be
	 * filled with elements.
	 * 
	 * Comparable<? super E> must be implemented for calling bubbleSort().
	 */
	public void sortReverse() {
		E[] sortedList = (E[]) new Comparable[size];

		int tempIndex = 0;
		Node temp = head.next;
		while (temp != tail) {
			for (int i = 0; i < temp.count; i++) {
				sortedList[tempIndex] = temp.data[i];
				tempIndex++;
			}
			temp = temp.next;
		}

		bubbleSort(sortedList);

		head.next = tail;
		tail.previous = head;

		size = 0;
		for (int i = 0; i < sortedList.length; i++) {
			add(sortedList[i]);
		}
	}
	
	/**
	 * Creates new StoutListIterator
	 */
	@Override
	public Iterator<E> iterator() {
		return new StoutListIterator();
	}
	
	/**
	 * Creates new StoutListIterator
	 */
	@Override
	public ListIterator<E> listIterator() {

		return new StoutListIterator();
	}

	/**
	 * Creates new StoutListIterator from index
	 */
	@Override
	public ListIterator<E> listIterator(int index) {

		return new StoutListIterator(index);
	}

	/**
	 * Returns a string representation of this list showing the internal structure
	 * of the nodes.
	 */
	public String toStringInternal() {
		return toStringInternal(null);
	}

	/**
	 * Returns a string representation of this list showing the internal structure
	 * of the nodes and the position of the iterator.
	 *
	 * @param iter an iterator for this list
	 */
	public String toStringInternal(ListIterator<E> iter) {
		int count = 0;
		int position = -1;
		if (iter != null) {
			position = iter.nextIndex();
		}

		StringBuilder sb = new StringBuilder();
		sb.append('[');
		Node current = head.next;
		while (current != tail) {
			sb.append('(');
			E data = current.data[0];
			if (data == null) {
				sb.append("-");
			} else {
				if (position == count) {
					sb.append("| ");
					position = -1;
				}
				sb.append(data.toString());
				++count;
			}

			for (int i = 1; i < nodeSize; ++i) {
				sb.append(", ");
				data = current.data[i];
				if (data == null) {
					sb.append("-");
				} else {
					if (position == count) {
						sb.append("| ");
						position = -1;
					}
					sb.append(data.toString());
					++count;

					// iterator at end
					if (position == size && count == size) {
						sb.append(" |");
						position = -1;
					}
				}
			}
			sb.append(')');
			current = current.next;
			if (current != tail)
				sb.append(", ");
		}
		sb.append("]");
		return sb.toString();
	}

	/**
	 * Node type for this list. Each node holds a maximum of nodeSize elements in an
	 * array. Empty slots are null.
	 */
	private class Node {

		

		/**
		 * Array of actual data elements.
		 */
		// Unchecked warning unavoidable.
		public E[] data = (E[]) new Comparable[nodeSize];

		/**
		 * Link to next node.
		 */
		public Node next;

		/**
		 * Link to previous node;
		 */
		public Node previous;

		/**
		 * Index of the next available offset in this node, also equal to the number of
		 * elements in this node.
		 */
		public int count;

		

		

		/**
		 * Adds an item to this node at the first available offset. Precondition: count
		 * < nodeSize
		 * 
		 * @param item element to be added
		 */
		void addItem(E item) {
			if (count >= nodeSize) {
				return;
			}
			data[count++] = item;
			// useful for debugging
		}

		/**
		 * Adds an item to this node at the indicated offset, shifting elements to the
		 * right as necessary.
		 * 
		 * Precondition: count < nodeSize
		 * 
		 * @param offset array index at which to put the new element
		 * @param item   element to be added
		 */
		void addItem(int offset, E item) {
			if (count >= nodeSize) {
				return;
			}
			for (int i = count - 1; i >= offset; --i) {
				data[i + 1] = data[i];
			}
			++count;
			data[offset] = item;
			// useful for debugging
			
		}

		/**
		 * Deletes an element from this node at the indicated offset, shifting elements
		 * left as necessary. Precondition: 0 <= offset < count
		 * 
		 * @param offset
		 */
		void removeItem(int offset) {
			// E item = data[offset];
			for (int i = offset + 1; i < nodeSize; ++i) {
				data[i - 1] = data[i];
			}
			data[count - 1] = null;
			--count;
		}

	}
	
	/**
	 * StoutIterator iterates through an individual node
	 */
	private class StoutIterator implements Iterator<E>{
		
		
		//index of cursor in node
		private int index;
		
		//node data array
		private E[] data;
		
		/**
		 * constructor with input array
		 * @param e
		 */
		public StoutIterator(E[] e) {
			index = 0;
			data = e;
		}
		
		/**
		 * returns if cursor has next position available
		 * @return true or false if it has next
		 */
		@Override
		public boolean hasNext() {
			
			if(index >= data.length) {
				return false;
			}
			return true;
		}
		
		/**
		 * returns item in array
		 */
		@Override
		public E next() {
			
			return data[index++];
		}
		
		/**
		 * subtracts 1 from index for remove method
		 */
		public void indexMinus() {
			index--;
		}
		
		/**
		 * returns whether cursor has previous possible array
		 * @return true or false if it has previous
		 */
		public boolean hasPrevious() {
			
			if(index > 0) {
				return true;
			}
			return false;
		}
		
		/**
		 * moves cursor to previous position in array
		 * @return previous array value
		 */
		public E previous() {
			
			return data[--index];
		}
		
		public void setIndexMax() {
			index=0;
			for(int i=0;i<data.length;i++) {
				if (data[i] != null) {
		            index++;
		        }
			}
		}
		
	}
	
	
	
	/**
	 * Iterates the nodes of StoutList and then it can iterate individual elements inside each node with a StoutIterater
	 */
	private class StoutListIterator implements ListIterator<E> {
		

		//direction variables
		private static final int BEHIND = -1;
		private static final int AHEAD = 1;
		private static final int NONE = 0;
		
		private Node cursor;
		private int index;
		private int direction;

		/**
		 * Default constructor
		 */
		StoutIterator itr;

		public StoutListIterator() {
			index = 0;
			cursor = head.next;
			direction = NONE;
			itr = new StoutIterator(cursor.data);
		}

		/**
		 * Constructor finds node at a given position.
		 * 
		 * @param pos
		 */
		public StoutListIterator(int pos) {
			if (pos < 0 || pos > size)
				throw new IndexOutOfBoundsException("" + pos);
			
			cursor = find(pos).node;
			index = pos;
			direction = NONE;
			itr = new StoutIterator(cursor.data);

		}

		/**
		 * returns whether iterator has next
		 */
		@Override
		public boolean hasNext() {
			return index < size;
		}

		/**
		 * goes to next element and potentially next node if there are no more elements in node
		 */
		@Override
		public E next() {
			
			
			
			
			
			E ret;
			
			if(!itr.hasNext()) {
				if (!hasNext())
				throw new NoSuchElementException();
				cursor = cursor.next;
				itr = new StoutIterator(cursor.data);
				
			}
			
			direction = BEHIND;
			
			ret = itr.next();
			
			++index;
			
			return ret;
		}

		/**
		 * removes last element returned by next or previous
		 */
		@Override
		public void remove() {
			if (direction == NONE) {
	            throw new IllegalStateException("Cannot remove without calling next() or previous().");
	        }

	        // Adjust for direction
			
	        if (direction == BEHIND) {
	        	StoutList.this.remove(--index);

	        }

	        
	        if (direction == AHEAD) {
	        	StoutList.this.remove(index);
	        }
	        
	        itr.indexMinus();
	        
	        NodeInfo nodeInfo = find(index);
	        cursor = nodeInfo.node;
	        
	        direction = NONE;
		}

		/**
		 * if iterator is not first node, return true
		 * @return hasPrevious
		 */
		@Override
		public boolean hasPrevious() {

			return index > 0;
		}

		/**
		 * opposite of next, goes to previous element in node and goes between nodes if needed
		 */
		@Override
		public E previous() {
			
			
			
			
			E ret;
			
			if(!itr.hasPrevious()) {
				if (!hasPrevious())
				throw new NoSuchElementException();
				cursor = cursor.previous;
				itr = new StoutIterator(cursor.data);
				itr.setIndexMax();
				
				
			}
			
			direction = AHEAD;
			
			ret = itr.previous();
			
			++index;
			
			return ret;
		}

		/**
		 * returns the next index of the cursor
		 */
		@Override
		public int nextIndex() {

			return index;
		}

		/**
		 * returns cursor's previous index
		 */
		@Override
		public int previousIndex() {

			return index - 1;
		}

		/**
		 * sets the object at the position of the cursor to the given object
		 */
		@Override
		public void set(E e) {
			if (e == null) {
				throw new NullPointerException();
			}
			//sets behind cursor
			if (direction == BEHIND) {
				
				NodeInfo nodeInfo = find(index - 1);
				nodeInfo.node.data[nodeInfo.offset] = e;
				
				//sets in front of cursor
			} else if (direction == AHEAD) {
				
				NodeInfo nodeInfo = find(index);
				nodeInfo.node.data[nodeInfo.offset] = e;
				
				//no direction
			} else {
				
				throw new IllegalStateException();
			}
			
		}

		/**
		 * adds object at index of cursor
		 */
		@Override
		public void add(E e) {
			
			if (e == null)
				throw new NullPointerException();

			StoutList.this.add(index, e);
			
			
			
			index++;

			direction = NONE;
		}

		
	}

	

	/**
	 * Sort an array arr[] using the insertion sort algorithm in the NON-DECREASING
	 * order.
	 * 
	 * @param arr  array storing elements from the list
	 * @param comp comparator used in sorting
	 */
	private void insertionSort(E[] e) {
		for (int i = 1; i < e.length; i++) {
			E key = e[i];
			int j = i - 1;

			while (j >= 0 && e[j].compareTo(key) > 0) {
				e[j + 1] = e[j];
				j--;
			}
			e[j + 1] = key;
		}
	}

	/**
	 * Sort arr[] using the bubble sort algorithm in the NON-INCREASING order. For a
	 * description of bubble sort please refer to Section 6.1 in the project
	 * description. You must use the compareTo() method from an implementation of
	 * the Comparable interface by the class E or ? super E.
	 * 
	 * @param arr array holding elements from the list
	 */
	private void bubbleSort(E[] e) {
		int n = e.length;
		for (int i = 0; i < n - 1; i++) {
			for (int j = 0; j < n - i - 1; j++) {
				if (e[j].compareTo(e[j + 1]) < 0) {
					E temp = e[j];
					e[j] = e[j + 1];
					e[j + 1] = temp;
				}
			}
		}
	}

	

	/**
	 * includes offset of node in the node's information
	 */
	private class NodeInfo {
		public Node node;
		public int offset;

		public NodeInfo(Node node, int offset) {
			this.node = node;
			this.offset = offset;
		}
	}

	/**
	 * finds the nodeinfo based on the position
	 * @param pos
	 * @return nodeinfo
	 */
	private NodeInfo find(int pos) {
		Node temp = head.next;

		int current = 0;

		//counts the items in each node, and does until it is out of items. the amount left is the offset
		while (temp != tail) {
			if (current + temp.count <= pos) {
				current += temp.count;
				temp = temp.next;
			} else {
				break;
			}

		}
		NodeInfo nodeInfo = new NodeInfo(temp, pos - current);
		return nodeInfo;

	}

	
}