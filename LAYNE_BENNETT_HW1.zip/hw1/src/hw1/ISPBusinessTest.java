package hw1;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class ISPBusinessTest {

	@Test
	void updatePlainTest() {//Tests updatePlain method by making 2x2 grid and updating it and testing the 0,0 tile of it
		Town test = new Town(2, 2);
		test.grid[0][0] = new Outage(test, 0, 0);
		test.grid[0][1] = new Empty(test, 0, 1);
		test.grid[1][0] = new Casual(test, 1, 0);
		test.grid[1][1] = new Streamer(test, 1, 1);
		test = ISPBusiness.updatePlain(test);
		assertEquals(test.grid[0][0].who(), State.EMPTY);
	}

	@Test
	void getProfitTest() {//Tests profit method by making 2x2 grid and testing for Casuals, expects 1

		Town test = new Town(2, 2);
		test.grid[0][0] = new Outage(test, 0, 0);
		test.grid[0][1] = new Empty(test, 0, 1);
		test.grid[1][0] = new Casual(test, 1, 0);
		test.grid[1][1] = new Streamer(test, 1, 1);
		ISPBusiness.getProfit(test);
		assertEquals(ISPBusiness.getProfitInt(), 1);

	}

	@Test
	void getPercentTest() {//Tests profit percent method by making 2x2 grid and testing for 100*casuals/grid, expects 25

		Town test = new Town(2, 2);
		test.grid[0][0] = new Outage(test, 0, 0);
		test.grid[0][1] = new Empty(test, 0, 1);
		test.grid[1][0] = new Casual(test, 1, 0);
		test.grid[1][1] = new Streamer(test, 1, 1);
		ISPBusiness.getProfit(test);
		ISPBusiness.getPercent();

		assertEquals(ISPBusiness.getPercentDouble(), 25);

	}

}