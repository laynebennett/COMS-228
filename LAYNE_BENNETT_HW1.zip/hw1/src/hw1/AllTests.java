package hw1;

import org.junit.platform.suite.api.SelectClasses;
import org.junit.platform.suite.api.Suite;

@Suite
@SelectClasses({ CasualTest.class, EmptyTest.class, ISPBusinessTest.class, OutageTest.class, ResellerTest.class,
		StreamerTest.class, TownCellTest.class, TownTest.class })
public class AllTests {

}
