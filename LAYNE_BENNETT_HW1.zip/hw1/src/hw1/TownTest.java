package hw1;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class TownTest {
	
	Town test = new Town(4,4);
	@Test
	void testLength() {//tests length method
		assertEquals(test.getLength(),4);
		
	}
	@Test
	void testWidth() {//tests width method
		assertEquals(test.getWidth(),4);
		
	}
	@Test
	void testRand() {//tests rand method
		test.randomInit(1);
		assertEquals(test.grid[0][0].who(),State.CASUAL);
		
	}
}
