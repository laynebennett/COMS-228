package hw1;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class CasualTest {
	
	
	
	@Test
	void testWho() {//Tests who method by making a 2x2 grid and testing the 0,0 tile
		Town test = new Town(2,2);
		test.grid[0][0] = new Casual(test,0,0);
		
		assertEquals(test.grid[0][0].who(), State.CASUAL);
		
	}
	@Test
	 void testNext1() {
		 Town test = new Town(2,2);//Tests next method case with 2x2 grid, expecting streamer
			test.grid[0][0] = new Outage(test,0,0);
			test.grid[0][1] = new Empty(test,0,1);
			test.grid[1][0] = new Casual(test,1,0);
			test.grid[1][1] = new Streamer(test,1,1);
	        assertEquals(State.STREAMER, test.grid[1][0].next(test).who());
	        
	    }
	@Test
	void testNext2() {
		 Town test = new Town(2,2);//Tests next method case with 2x2 grid, expecting outage
			test.grid[0][0] = new Reseller(test,0,0);
			test.grid[0][1] = new Casual(test,0,1);
			test.grid[1][0] = new Casual(test,1,0);
			test.grid[1][1] = new Casual(test,1,1);
	        assertEquals(State.RESELLER, test.grid[0][1].next(test).who());
	        
	    }

}
