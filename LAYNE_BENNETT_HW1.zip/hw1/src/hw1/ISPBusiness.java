package hw1;

import java.io.FileNotFoundException;
import java.util.Scanner;

/**
 * @author Layne Bennett
 *
 *         The ISPBusiness class performs simulation over a grid plain with
 *         cells occupied by different TownCell types.
 *
 */

public class ISPBusiness {

	private static int input;
	private static int length;
	private static int width;
	private static double percentageProfit=0;
	private static int profitTotal=0;
	private static int itr=0;

	/**
	 * Returns a new Town object with updated grid value for next billing cycle.
	 * 
	 * @param tOld: old/current Town object.
	 * @return: New town object.
	 */
	public static Town updatePlain(Town tOld) {
		length = tOld.getLength();
		width = tOld.getWidth();
		
		Town tNew = new Town(tOld.getLength(), tOld.getWidth());
		for (int i = 0; i < length; i++) {
			for (int j = 0; j < width; j++) {
				tNew.grid[i][j] = tOld.grid[i][j].next(tNew);
			}
		}
		itr++;
		printGrid(tNew);
		getProfit(tNew);
		
		return tNew;
	}

	/**
	 * Returns the profit for the current state in the town grid.
	 * 
	 * @param town
	 * @return
	 */
	public static void getProfit(Town town) {
		//
		int profit = 0;
		length = town.getLength();
		width = town.getWidth();
		for(int i=0;i<length; i++) {
			for (int j =0;j<width; j++) {
				if(town.grid[i][j].who().equals(State.CASUAL)) {
					profit++;
				}
				}

			} 
		
		System.out.println("Profit: "+profit);
		System.out.println("");
		profitTotal = profitTotal+profit;

	}
	/**
	 * returns profitTotal
	 * @return profitTotal
	 */
	public static int getProfitInt() {
		return profitTotal;
	}
	/**
	 * calculates the percent profit from profitTotal and iterations,
	 * and finishes by assigning percentageProft and printing it.
	 */
	public static void getPercent() {
		percentageProfit = 100*(((double)profitTotal)/(itr+1))/(width*length);
		System.out.printf("Profit percent: %.2f%%\n\n", percentageProfit);

	}
	/**
	 * Returns the value of percentageProfit, used for testing.
	 * @return percentageProfit
	 */
	public static double getPercentDouble() {
		return percentageProfit;
	}
	
	
/**
 * Prints the town that is declared in the parameter, with each row separated by a line
 * @param town
 */
	public static void printGrid(Town town) {
		System.out.println("After itr: "+itr);
		for (int i = 0; i < length; i++) {
			for (int j = 0; j < width; j++) {
				System.out.print(town.grid[i][j].who().toString().charAt(0) + " ");
			}
			System.out.println("");
		}
	}
/**
	 * Main method. Interact with the user and ask if user wants to specify elements
	 * of grid via an input file (option: 1) or wants to generate it randomly
	 * (option: 2).
	 * 
	 * Depending on the user choice, create the Town object using respective
	 * constructor and if user choice is to populate it randomly, then populate the
	 * grid here.
	 * 
	 * Finally: For 12 billing cycle calculate the profit and update town object
	 * (for each cycle). Print the final profit in terms of %. You should print the
	 * profit percentage with two digits after the decimal point: Example if profit
	 * is 35.5600004, your output should be:
	 *
	 * 35.56%
	 * 
	 * Note that this method does not throw any exception, so you need to handle all
	 * the exceptions in it.
	 * 
	 * @param args
	 * 
	 */
	public static void main(String[] args) {
		//    C:\Users\Layne\Downloads\ISP4x4.txt
		Scanner scnr = new Scanner(System.in);
		System.out.println("How to populate grid (type 1 or 2):");
		System.out.println("1: from a file");
		System.out.println("2: randomly with seed");
		input = scnr.nextInt();
		Town town = null;
		if (input == 1) {
			System.out.println("Please enter file path:");
			String filePath = scnr.next();
			System.out.println("filePath: " + filePath);
			try {
				town = new Town(filePath);
				length = town.getLength();
				width = town.getWidth();
			} catch (FileNotFoundException e) {
				System.out.println("File not found: " + filePath);
			}

		} else if (input == 2) {
			System.out.println("length of Town?");
			length = scnr.nextInt();
			System.out.println("width of Town?");
			width = scnr.nextInt();
			town = new Town(length, width);
			System.out.println("seed?");
			Scanner scnrSeed = new Scanner(System.in);
			int randomSeed = scnrSeed.nextInt();
			town.randomInit(randomSeed);
			scnrSeed.close();
			scnr.close();
			System.out.println("length: " + length);
			System.out.println("width: " + width);

			// town.censusTest();
		} else {
			System.out.println("Incorrect input, try again.");
		}
		scnr.close();
		printGrid(town);
		getProfit(town);
		
		for(int i=0;i<11;i++) {
			town = updatePlain(town);
		}
		getPercent();
	}
}
