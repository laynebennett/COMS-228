package hw1;

public class Casual extends TownCell{

	public Casual(Town p, int r, int c) {
        super(p, r, c);
    }

    @Override
    public State who() {
        return State.CASUAL;//returns cell state
    }

    /**
     * Assigns Casual cell with its next state based on its neighbors
     */
    @Override
    public TownCell next(Town tNew) {
    	 census(nCensus); // Take a census of the neighbors
    	if (nCensus[EMPTY]+nCensus[OUTAGE] <=1) {
            return new Reseller(tNew, row, col);  //Any cell that (1) is not a Reseller or Outage and (2) and has (Number of Empty + Number of Outage neighbors less than or equal to 1) converts to Reseller.
        }else if (nCensus[RESELLER] >=1) {
            return new Outage(tNew, row, col);  //If there is any reseller in the neighborhood, the reseller causes outage for the streamer as well.
        }else if (nCensus[STREAMER] >=1) {
            return new Streamer(tNew, row, col);  //casual cell is inspired to become streamer
        }else if (nCensus[CASUAL] >= 5) {
        	return new Streamer(tNew, row, col);////If none of the above rules apply, any cell with 5 or more casual neighbors becomes a Streamer
        }
    	return new Casual(tNew, row, col);//If none of the rules apply, then the cell state remains unchanged for the next iteration.
    }
}
