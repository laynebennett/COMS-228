package hw1;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Random;
import java.util.Scanner;

/**
 * @author Layne Bennett
 *
 */
public class Town {

	private int length, width; // Row and col (first and second indices)
	public TownCell[][] grid; //grid to be used for location in town
	int cellInt; //used in randInit to turn ints into cell types
	/**
	 * Constructor to be used when user wants to generate grid randomly, with the
	 * given seed. This constructor does not populate each cell of the grid (but
	 * should assign a 2D array to it).
	 * 
	 * @param length
	 * @param width
	 */
	public Town(int length, int width) {
		grid = new TownCell[length][width];
		this.length = length;
		this.width = width;
		
		
	}

	/**
	 * Constructor to be used when user wants to populate grid based on a file.
	 * Please see that it simple throws FileNotFoundException exception instead of
	 * catching it. Ensure that you close any resources (like file or scanner) which
	 * is opened in this function.
	 * 
	 * @param inputFileName
	 * @throws FileNotFoundException
	 */
	public Town(String inputFileName) throws FileNotFoundException {
		File file = new File(inputFileName); //creates scanner for file opened
		Scanner fileScnr = new Scanner(file);
		this.length = fileScnr.nextInt(); //assigns length and width for grid
		this.width = fileScnr.nextInt();
		this.grid = new TownCell[length][width];
		String scnrLine = "TEMPORARY"; //string for scanning line by line
		char cellChar; //for scanning individual char in txt file
		scnrLine = fileScnr.nextLine();
		for (int i = 0; i < length; i++) { //each letter is scanned and assigned a grid spot based on cellChar
			scnrLine = fileScnr.nextLine();
			System.out.println("");
			for (int j = 0; j < width; j++) {
				cellChar = scnrLine.charAt(j * 2);
				switch (cellChar) {
				case 'O':
					grid[i][j] = new Outage(this, i,j);
					break;
				case 'R':
					grid[i][j] = new Reseller(this, i,j);
					break;
				case 'E':
					grid[i][j] = new Empty(this, i,j);
					break;
				case 'S':
					grid[i][j] = new Streamer(this, i,j);
					break;
				case 'C':
					grid[i][j] = new Casual(this, i,j);
					break;

				}
			}

		}
		fileScnr.close();
		System.out.println("");
	}

	/**
	 * Returns width of the grid.
	 * 
	 * @return
	 */
	public int getWidth() {

		return width;
	}

	/**
	 * Returns length of the grid.
	 * 
	 * @return
	 */
	public int getLength() {

		return length;
	}

	/**
	 * Initialize the grid by randomly assigning cell with one of the following
	 * class object: Casual, Empty, Outage, Reseller OR Streamer
	 */
	public void randomInit(int seed) {
		Random rand = new Random(seed);
		for (int i = 0; i < length; i++) { //assigns each cell a type based on a random int
			System.out.println("");
			for (int j = 0; j < width; j++) {
				cellInt = rand.nextInt(4);
				switch (cellInt) {
				case 0:
					grid[i][j] = new Outage(this, i,j);
					break;
				case 1:
					grid[i][j] = new Reseller(this, i,j);
					break;
				case 2:
					grid[i][j] = new Casual(this, i,j);
					break;
				case 3:
					grid[i][j] = new Streamer(this, i,j);
					break;
				case 4:
					grid[i][j] = new Empty(this, i,j);
					break;

				}
			}

		}
		System.out.println("");
	}

	/**
	 * Output the town grid. For each square, output the first letter of the cell
	 * type. Each letter should be separated either by a single space or a tab. And
	 * each row should be in a new line. There should not be any extra line between
	 * the rows.
	 */
	@Override
	public String toString() {
		String s = "";
		// TODO: Write your code here.
		return s;
	}
	
}
