package hw1;

/**
 * 
 * @author Layne Bennett Also provide appropriate comments for this class
 *
 */
public abstract class TownCell {

	protected Town plain;
	protected int row;
	protected int col;

	// constants to be used as indices.
	protected static final int RESELLER = 0;
	protected static final int EMPTY = 1;
	protected static final int CASUAL = 2;
	protected static final int OUTAGE = 3;
	protected static final int STREAMER = 4;

	public static final int NUM_CELL_TYPE = 5;

	// Use this static array to take census.
	public static final int[] nCensus = new int[NUM_CELL_TYPE];

	public TownCell(Town p, int r, int c) {
		plain = p;
		row = r;
		col = c;
	}

	/**
	 * Checks all neighborhood cell types in the neighborhood. Refer to homework pdf
	 * for neighbor definitions (all adjacent neighbors excluding the center cell).
	 * Use who() method to get who is present in the neighborhood
	 * 
	 * @param counts of all customers
	 */
	public void census(int nCensus[]) {
		// zero the counts of all customers
		nCensus[RESELLER] = 0;
		nCensus[EMPTY] = 0;
		nCensus[CASUAL] = 0;
		nCensus[OUTAGE] = 0;
		nCensus[STREAMER] = 0;
		
		TownCell neighbor; //creates a new townCell neighbor that will be a placeholder for all neighbors scanned
		for (int i = row - 1; i <= row + 1; i++) {
			for (int j = col - 1; j <= col + 1; j++) {
				if (((i == row && j == col)||i<0||j<0||i>=plain.getLength()||j>=plain.getWidth())!=true) {
					neighbor = plain.grid[i][j]; //assigning neighbor to the spot in the grid scanned
					switch (neighbor.who()) {
					case OUTAGE:
						//System.out.print("O neighbor");
						nCensus[OUTAGE]++;
						break;
					case RESELLER:
						//System.out.print("R neighbor");
						nCensus[RESELLER]++;
						break;
					case EMPTY:
						//System.out.print("E neighbor");
						nCensus[EMPTY]++;
						break;
					case STREAMER:
						//System.out.print("S neighbor");
						nCensus[STREAMER]++;
						break;
					case CASUAL:
						//System.out.print("C neighbor");
						nCensus[CASUAL]++;
						break;

					}
				}
			

			}
		}
	}

	/**
	 * Gets the identity of the cell.
	 * 
	 * @return State
	 */
	public abstract State who();

	/**
	 * Determines the cell type in the next cycle.
	 * 
	 * @param tNew: town of the next cycle
	 * @return TownCell
	 */
	public abstract TownCell next(Town tNew);
}
