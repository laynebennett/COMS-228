package hw1;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class TownCellTest {
	
	@Test
	void testNCensus() {//tests nCensus method by making 2x2 town and testing neighbors, expecting 1 empty neighor
		int[] nCensus = new int[5];
		
		Town test = new Town(2,2);
		test.grid[0][0] = new Outage(test,0,0);
		test.grid[0][1] = new Empty(test,0,1);
		test.grid[1][0] = new Casual(test,1,0);
		test.grid[1][1] = new Streamer(test,1,1);
		
		test.grid[0][0].census(nCensus);
		assertEquals(nCensus[1], 1);
	}

}
