package hw1;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class OutageTest {

	@Test
	void testWho() { //Tests who method by making a 2x2 grid and testing the 0,0 tile
		Town test = new Town(2,2);
		test.grid[0][0] = new Outage(test,0,0);
		
		assertEquals(test.grid[0][0].who(), State.OUTAGE);
		
	}
	@Test
	 void testNext() {//Tests next method case with 2x2 grid, expecting empty
		 Town test = new Town(2,2);
			test.grid[0][0] = new Outage(test,0,0);
			test.grid[0][1] = new Empty(test,0,1);
			test.grid[1][0] = new Casual(test,1,0);
			test.grid[1][1] = new Streamer(test,1,1);
	        assertEquals(State.EMPTY, test.grid[0][0].next(test).who());
	        
	    }

}
