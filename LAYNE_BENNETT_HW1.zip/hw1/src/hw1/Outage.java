package hw1;

public class Outage extends TownCell{

	public Outage(Town p, int r, int c) {
        super(p, r, c);
    }

    @Override
    public State who() {
        return State.OUTAGE;//returns cell state
    }
    /**
     * Assigns Outage cell with its next state based on its neighbors
     */
    @Override
    public TownCell next(Town tNew) {
    	 census(nCensus); // Take a census of the neighbors
    	return  new Empty(tNew, row, col);//always turns to empty cell
    }
}
