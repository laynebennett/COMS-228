package hw1;

public class Reseller extends TownCell{

	public Reseller(Town p, int r, int c) {
        super(p, r, c);
    }

    @Override
    public State who() {
        return State.RESELLER;//returns cell state
    }
    /**
     * Assigns Reseller cell with its next state based on its neighbors
     */
    @Override
    public TownCell next(Town tNew) {
        census(nCensus);  // Take a census of the neighbors

        if (nCensus[EMPTY] >= 3||nCensus[CASUAL] <= 3) {//If there are 3 or fewer casual users in the neighborhood, then Reseller finds it unprofitable to maintain the business and leaves, making the cell Empty.
            return new Empty(tNew, row, col);   //Also, if there are 3 or more empty cells in the neighborhood, then the Reseller leaves, making the cell Empty. Resellers do not like unpopulated regions. 
        }else if (nCensus[EMPTY]+nCensus[OUTAGE] <=1) {//converts to reseller if outage and empty is less than or equal to 1
            return new Reseller(tNew, row, col);  
        }else if (nCensus[CASUAL] >= 5) {//If none of the above rules apply, any cell with 5 or more casual neighbors becomes a Streamer
        	return new Streamer(tNew, row, col);
        }
        return new Reseller(tNew, row, col);  //If none of the rules apply, then the cell state remains unchanged for the next iteration.
    }
}
