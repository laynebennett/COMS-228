package edu.iastate.cs2280.hw2;

import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Scanner;
import java.util.Random;
/**
 * @author Layne Bennett
 */
/**
 * This class compares the sorters by type and time to run.
 */
public class CompareSorters {
	/**
	 * Repeatedly take integer sequences either randomly generated or read from
	 * files. Use them as coordinates to construct points. Scan these points with
	 * respect to their median coordinate point four times, each time using a
	 * different sorting algorithm.
	 * 
	 * @param args
	 * @throws IOException
	 **/
	public static void main(String[] args) throws IOException, FileNotFoundException {
		// Run multiple rounds comparing sorting algorithms
		// Options: random points or points from a file
		// Run each using SelectionSort, InsertionSort, MergeSort, and QuickSort

		PointScanner[] scanners; // Array of PointScanners

		int trial = 1; // Track trial count

		System.out.println("Performances of Four Sorting Algorithms in Point Scanning");
		System.out.println();
		System.out.println("keys: 1 (random integers) 2 (file input) 3 (exit)");

		Scanner scnr = new Scanner(System.in); // Scanner for user input
		int scnrInt = 0; // Hold user option

		while (scnrInt != 3) {

			System.out.print("Trial " + trial + ": "); // Display trial number

			scnrInt = scnr.nextInt(); // Get user input
			trial++; // Increment trial count
			System.out.println();

			if (scnrInt == 1) { // Random points case
				System.out.print("Enter number of random points: ");
				int pointNum = scnr.nextInt(); // Get number of points
				Random rand = new Random(10); // Random object with seed 10
				Point[] randPointArray = new Point[pointNum];
				randPointArray = generateRandomPoints(pointNum, rand); // Generate random points

				// Assign scanners to the 4 sorting algorithms
				scanners = new PointScanner[4];
				scanners[0] = new PointScanner(randPointArray, Algorithm.valueOf("SelectionSort"));
				scanners[1] = new PointScanner(randPointArray, Algorithm.valueOf("InsertionSort"));
				scanners[2] = new PointScanner(randPointArray, Algorithm.valueOf("MergeSort"));
				scanners[3] = new PointScanner(randPointArray, Algorithm.valueOf("QuickSort"));

				outPrint(scanners); // Print stats

			} else if (scnrInt == 2) { // File input case
				System.out.println("Points from a file");
				System.out.print("File name: ");
				String filename = scnr.next(); // Get filename
				
				// Assign scanners to the 4 sorting algorithms
				scanners = new PointScanner[4];
				try {
				scanners[0] = new PointScanner(filename, Algorithm.valueOf("SelectionSort"));
				scanners[1] = new PointScanner(filename, Algorithm.valueOf("InsertionSort"));
				scanners[2] = new PointScanner(filename, Algorithm.valueOf("MergeSort"));
				scanners[3] = new PointScanner(filename, Algorithm.valueOf("QuickSort"));
				}catch(FileNotFoundException e) {
					scnr.close();
					throw new FileNotFoundException("File not found: " + filename);
					
				}
				outPrint(scanners); // Print stats

			} else if (scnrInt == 3) { // Exit option
				break; // Exit loop
			} else {
				System.out.println("Please enter valid number."); // Handle invalid input
			}

		}
		scnr.close(); // Close the scanner

		// For each input of points:
		// - Initialize the array scanners[]
		// - Have every scanner call the scan() method
		// - After all four scans, print the stats table
	}

	/**
	 * Prints the outcome of each sorting algorithm on the point array. 
	 * This includes the algorithm type, the size of array, and time to sort.
	 * @param scanners
	 * @throws IOException
	 */
	// Print stats for each algorithm
	private static void outPrint(PointScanner[] scanners) throws IOException {

		System.out.println();
		System.out.println();
		System.out.println("algorithm size time (ns)");
		System.out.println("----------------------------------");

		try {
			FileWriter fileWriter = new FileWriter("MCP.txt", false); // true means append mode
			PrintWriter writer = new PrintWriter(new FileWriter("example.txt")); // Overwrite mode by default

			writer.close();
			fileWriter.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
		for (int i = 0; i < 5; i++) { //warm up runs for the scanners
			for (PointScanner scanner : scanners) {
				scanner.scan(); // Run scan
			}
		}

		for (PointScanner scanner : scanners) {
			scanner.scan(); // Run scan
			System.out.println(scanner.stats()); // Print stats for each
		}
		System.out.println("----------------------------------");
		System.out.println();
	}

	/**
	 * This method generates a given number of random points. The coordinates of
	 * these points are pseudo-random numbers within the range [-50,50] � [-50,50].
	 * Please refer to Section 3 on how such points can be generated.
	 * 
	 * Ought to be private. Made public for testing.
	 * 
	 * @param numPts number of points
	 * @param rand   Random object to allow seeding of the random number generator
	 * @throws IllegalArgumentException if numPts < 1
	 */
	public static Point[] generateRandomPoints(int numPts, Random rand) throws IllegalArgumentException {
		if (numPts < 1) { // Invalid point count check
			throw new IllegalArgumentException("numPts must be greater than 0");
		}

		Point[] randArray = new Point[numPts]; // Array to store points

		for (int i = 0; i < numPts; i++) { // Generate points
			int xRand = rand.nextInt(101) - 50; // Random x-coordinate
			int yRand = rand.nextInt(101) - 50; // Random y-coordinate

			randArray[i] = new Point(xRand, yRand); // Create and store point
		}
		return randArray; // Return array of points
	}

}
