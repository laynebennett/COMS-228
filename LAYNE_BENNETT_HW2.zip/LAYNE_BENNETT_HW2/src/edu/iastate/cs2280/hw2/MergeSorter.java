package edu.iastate.cs2280.hw2;

//import java.io.FileNotFoundException;
//import java.lang.NumberFormatException; 
//import java.lang.IllegalArgumentException; 
//import java.util.InputMismatchException;

/**
 *  
 * @author Layne Bennett
 *
 */

/**
 * 
 * This class implements the mergesort algorithm.   
 *
 */

public class MergeSorter extends AbstractSorter
{
	// Other private instance variables if needed
	
	/** 
	 * Constructor takes an array of points.  It invokes the superclass constructor, and also 
	 * set the instance variables algorithm in the superclass.
	 *  
	 * @param pts   input array of integers
	 */
	public MergeSorter(Point[] pts) 
	{
		super(pts);  // Call to superclass constructor
		algorithm = "MergeSort";  // Set algorithm name
	}


	/**
	 * Perform mergesort on the array points[] of the parent class AbstractSorter. 
	 * 
	 */
	@Override 
	public void sort()
	{
        mergeSortRec(points);  // Start recursive merge sort
	}

	
	/**
	 * This is a recursive method that carries out mergesort on an array pts[] of points. One 
	 * way is to make copies of the two halves of pts[], recursively call mergeSort on them, 
	 * and merge the two sorted subarrays into pts[].   
	 * 
	 * @param pts	point array 
	 */
	private void mergeSortRec(Point[] pts)
	{
		int n = pts.length;  
		if(pts.length<2) {  // Base case for recursion
			return;
		}
		int mid = (n)/2;  // Midpoint of the array
		Point[] left = new Point[mid];  // Left half
		Point[] right = new Point[n-mid];  // Right half
		
		// Copy left half
		for(int i=0; i<mid; i++) {
			left[i] = pts[i];
		}
		
		// Copy right half
		for(int i=mid; i<n; i++) {
			right[i-mid] = pts[i];
		}

		mergeSortRec(left);  // Recursively sort left half
		mergeSortRec(right);  // Recursively sort right half
		
		merge(pts, left, right);  // Merge sorted halves
	}

	/**Merge two sorted arrays back into pts[]
	 * 
	 * @param pts
	 * @param left
	 * @param right
	 */
	public void merge(Point[] pts, Point[] left, Point[] right) {
		
		int i=0, j=0, k = 0;  // Index trackers
		
		while (i<left.length && j<right.length) {  // Merge left and right arrays
			if(pointComparator.compare(left[i], right[j]) <= 0) {
				pts[k++] = left[i++];  // Copy from left
			}else {
				pts[k++] = right[j++];  // Copy from right
			}
		}
		
		// Copy remaining elements from left array, if any
		while (i < left.length) {
	        pts[k++] = left[i++];
	    }
	    // Copy remaining elements from right array, if any
	    while (j < right.length) {
	        pts[k++] = right[j++];
	    }
	}
	// Other private methods if needed ...

}
