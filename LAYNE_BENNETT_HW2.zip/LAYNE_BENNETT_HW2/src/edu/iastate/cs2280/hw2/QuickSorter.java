package edu.iastate.cs2280.hw2;

//import java.io.FileNotFoundException;
//import java.lang.NumberFormatException; 
//import java.lang.IllegalArgumentException; 
//import java.util.InputMismatchException;

/**
 *  
 * @author Layne Bennett
 *
 */

/**
 * 
 * This class implements the version of the quicksort algorithm presented in the lecture.   
 *
 */

public class QuickSorter extends AbstractSorter
{
	
	// Other private instance variables if you need ... 
			
	/** 
	 * Constructor takes an array of points.  It invokes the superclass constructor, and also 
	 * set the instance variables algorithm in the superclass.
	 *   
	 * @param pts   input array of integers
	 */
	public QuickSorter(Point[] pts)
	{
		super(pts);  // Call superclass constructor
		algorithm = "QuickSort";  // Set algorithm name
	}
		

	/**
	 * Carry out quicksort on the array points[] of the AbstractSorter class.  
	 * 
	 */
	@Override 
	public void sort()
	{
		quickSortRec(0, points.length - 1);  // Start recursive quicksort
	}
	
	
	/**
	 * Operates on the subarray of points[] with indices between first and last. 
	 * 
	 * @param first  starting index of the subarray
	 * @param last   ending index of the subarray
	 */
	private void quickSortRec(int first, int last)
	{
		if (first < last) {  // Base case for recursion
            int pivotIndex = partition(first, last);  // Get pivot index
            quickSortRec(first, pivotIndex - 1);  // Recur on left half
            quickSortRec(pivotIndex + 1, last);  // Recur on right half
        }
	}
	
	
	/**
	 * Operates on the subarray of points[] with indices between first and last.
	 * 
	 * @param first
	 * @param last
	 * @return
	 */
	private int partition(int first, int last)
	{
		Point pivot = points[last];  // Choose pivot
		int i = first - 1;  // Index of smaller element

        // Iterate and compare with pivot
        for (int j = first; j < last; j++) {
            if (pointComparator.compare(points[j], pivot) < 0) {
                i++;
                swap(i, j);  // Swap elements
            }
        }
        swap(i + 1, last);  // Swap pivot into correct position
        return i + 1;  // Return pivot index
	}	
		


	
	// Other private methods if needed ...
}
