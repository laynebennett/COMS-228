package edu.iastate.cs2280.hw2;

/**
 *  
 * @author Layne Bennett
 *
 */
/**
 * This class implements the object type Point with an x any y coordinate attached to each point
 * 
 */
public class Point implements Comparable<Point>
{
	private int x; 
	private int y;
	
	public static boolean xORy;  // Determines whether to compare by x or y coordinates
	/**
	 * Default constructor
	 */
	public Point()  // Default constructor
	{
		// x and y get default value 0
	}
	
	/**
	 * Constructor for x and y input
	 */
	public Point(int x, int y)  // Constructor with parameters
	{
		this.x = x;  
		this.y = y;   
	}
	
	/**
	 * Constructor to copy a point
	 */
	public Point(Point p) { // Copy constructor
		x = p.getX();
		y = p.getY();
	}
	
	/**
	 * gets x of point
	 * @return x
	 */
	public int getX()   
	{
		return x;
	}
	/**
	 * gets y of point
	 * @return y
	 */
	public int getY()
	{
		return y;
	}
	
	/** 
	 * Set the value of the static variable xORy to determine comparison axis.
	 * @param xORy boolean indicating comparison by x (true) or y (false)
	 */
	public static void setXorY(boolean xORy)
	{
		Point.xORy = xORy;  // Assign value to xORy
	}
	
	/**
	 * returns if the points are equal or not by comparing them
	 * @return true if x and y are same on both points
	 */
	@Override
	public boolean equals(Object obj)
	{
		if (obj == null || obj.getClass() != this.getClass())
		{
			return false;
		}
    
		Point other = (Point) obj;
		return x == other.x && y == other.y;  // Compare x and y for equality
	}

	/**
	 * Compare this point with another point q based on xORy value.
	 * 
	 * @param q Point to compare to
	 * @return -1 if this is smaller, 0 if equal, 1 if this is larger
	 */
	public int compareTo(Point q)
	{
		if ((xORy && (this.x < q.x || (this.x == q.x && this.y < q.y))) || 
		    (!xORy && (this.y < q.y || (this.y == q.y && this.x < q.x)))) {
			return -1;
		}
		if (this.x == q.x && this.y == q.y) {
			return 0;  // Points are equal
		}
		return 1;  // This point is larger
	}
	
	/**
	 * Output the point in the format (x, y).
	 */
	@Override
    public String toString() 
	{
		return "(" + x + ", " + y + ")";  // String representation of the point
	}
}
