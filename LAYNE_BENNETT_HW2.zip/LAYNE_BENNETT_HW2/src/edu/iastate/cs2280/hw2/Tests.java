package edu.iastate.cs2280.hw2;

import static org.junit.jupiter.api.Assertions.*;

//import java.io.File;
import java.io.IOException;
import java.util.InputMismatchException;
import java.util.Random;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

/**
 * 
 * tests for hw2
 * 
 */
class Tests {
	Point[] points;
	Random rand;
	
	@BeforeEach
	void init() {
		rand = new Random();
	}
	
	@Test
	void mergeSorterRandomGenerator() {
		points = CompareSorters.generateRandomPoints(25, rand);
		MergeSorter m = new MergeSorter(points);
		m.setComparator(0);
		m.sort();
		for (int i = 1; i < points.length; i++)
		{
			if (m.points[i - 1].compareTo(m.points[i]) > 0)
			{
				fail("not sorted");
			}
		}
		assertEquals(true, Point.xORy);
		assertEquals("MergeSort", m.algorithm);
		
		m.setComparator(1);
		m.sort();
		for (int i = 1; i < points.length; i++)
		{
			if (m.points[i - 1].compareTo(m.points[i]) > 0)
			{
				fail("not sorted");
			}
		}
		assertEquals(false, Point.xORy);
	}

	
	@Test
	void insertionSorterRandomGenerator() {
		points = CompareSorters.generateRandomPoints(25, rand);
		InsertionSorter m = new InsertionSorter(points);
		m.setComparator(0);
		m.sort();
		for (int i = 1; i < points.length; i++)
		{
			if (m.points[i - 1].compareTo(m.points[i]) > 0)
			{
				fail("not sorted");
			}
		}
		assertEquals(true, Point.xORy);
		assertEquals("InsertionSort", m.algorithm);
		
		m.setComparator(1);
		m.sort();
		for (int i = 1; i < points.length; i++)
		{
			if (m.points[i - 1].compareTo(m.points[i]) > 0)
			{
				fail("not sorted");
			}
		}
		
		assertEquals(false, Point.xORy);

	}
	
	@Test
	void quickSorterRandomGenerator() {
		points = CompareSorters.generateRandomPoints(25, rand);
		QuickSorter m = new QuickSorter(points);
		m.setComparator(0);
		m.sort();
		for (int i = 1; i < points.length; i++)
		{
			if (m.points[i - 1].compareTo(m.points[i]) > 0)
			{
				fail("not sorted");
			}
		}
		assertEquals(true, Point.xORy);
		assertEquals("QuickSort", m.algorithm);
		
		m.setComparator(1);
		m.sort();
		for (int i = 1; i < points.length; i++)
		{
			if (m.points[i - 1].compareTo(m.points[i]) > 0)
			{
				fail("not sorted");
			}
		}
		
		assertEquals(false, Point.xORy);

	}
	
	@Test
	void selectionSorterRandomGenerator() {
		points = CompareSorters.generateRandomPoints(25, rand);
		SelectionSorter m = new SelectionSorter(points);
		m.setComparator(0);
		m.sort();
		for (int i = 1; i < points.length; i++)
		{
			if (m.points[i - 1].compareTo(m.points[i]) > 0)
			{
				fail("not sorted");
			}
		}
		assertEquals(true, Point.xORy);
		assertEquals("SelectionSort", m.algorithm);
		
		m.setComparator(1);
		m.sort();
		for (int i = 1; i < points.length; i++)
		{
			if (m.points[i - 1].compareTo(m.points[i]) > 0)
			{
				fail("not sorted");
			}
		}
		
		assertEquals(false, Point.xORy);
	}
	
	@Test
	void pointScanner() throws InputMismatchException, IOException {
		PointScanner[] scanners = new PointScanner[4]; 
		
		scanners[0] = new PointScanner("src/hw2/points.txt", Algorithm.SelectionSort);
		scanners[1] = new PointScanner("src/hw2/points.txt", Algorithm.MergeSort);
		scanners[2] = new PointScanner("src/hw2/points.txt", Algorithm.QuickSort);
		scanners[3] = new PointScanner("src/hw2/points.txt", Algorithm.InsertionSort);
		
		for (PointScanner ps: scanners) {
			ps.scan();
			System.out.println(ps.stats());
			//ps.writeMCPToFile();
			Point[] pointslol = new Point[17];
			pointslol = ps.getPoints();
			for (Point lol: pointslol) {
				System.out.println(lol.toString());
			}
		}
		
		scanners = new PointScanner[4]; 
		
		scanners[0] = new PointScanner("src/hw2/points.txt", Algorithm.SelectionSort);
		scanners[1] = new PointScanner("src/hw2/points.txt", Algorithm.MergeSort);
		scanners[2] = new PointScanner("src/hw2/points.txt", Algorithm.QuickSort);
		scanners[3] = new PointScanner("src/hw2/points.txt", Algorithm.InsertionSort);
		
		for (PointScanner ps: scanners) {
			ps.scan();
			System.out.println(ps.stats());
			//ps.writeMCPToFile();
			Point[] pointslol = new Point[17];
			pointslol = ps.getPoints();
			for (Point lol: pointslol) {
				System.out.println(lol.toString());
			}
		}
	}
	
}
