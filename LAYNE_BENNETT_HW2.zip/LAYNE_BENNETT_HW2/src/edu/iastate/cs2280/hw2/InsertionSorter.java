package edu.iastate.cs2280.hw2;

//import java.io.FileNotFoundException;  // Not used here
//import java.lang.NumberFormatException;  // Unused exception handling
//import java.lang.IllegalArgumentException;  // Not needed
//import java.util.InputMismatchException;  // Not required for this class


/**
 *  
 * @author Layne Bennett
 *
 */

/**
 * 
 * This class implements insertion sort.   
 *
 */

public class InsertionSorter extends AbstractSorter 
{
	// Other private instance vars if needed...
	
	/**
	 * Constructor takes an array of points.  It invokes the superclass constructor, and also 
	 * set the instance variables algorithm in the superclass.
	 * 
	 * @param pts  
	 */
	public InsertionSorter(Point[] pts) 
	{
		// Call parent constructor
		super(pts);
		this.algorithm = "InsertionSort";  // Set algo name
	}	

	
	/** 
	 * Perform insertion sort on the array points[] of the parent class AbstractSorter.  
	 */
	@Override 
	public void sort()
	{
		// Start sorting from index 1
		for(int i = 1; i < points.length; i++) {
			int j = i - 1;  // Track previous index
			Point key = points[i];  // Current element to insert
			
			// Shift elements until the right place for key is found
			while(j >= 0 && pointComparator.compare(points[j], key) > 0) {
				points[j + 1] = points[j];  // Shift right
				j--;
			}
			points[j + 1] = key;  // Insert the key at its correct position
		}
	}		
}
