package edu.iastate.cs2280.hw2;

/**
 * 
 * Four sorting algorithms 
 *
 */
public enum Algorithm 
{
	SelectionSort, InsertionSort, MergeSort, QuickSort
}
