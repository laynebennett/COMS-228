package edu.iastate.cs2280.hw2;

//import java.io.FileNotFoundException;  // Not needed for now
//import java.lang.NumberFormatException;  // Not being used
//import java.lang.IllegalArgumentException;  // Unused exception handling
//import java.util.InputMismatchException;  // Not required for this class


/**
 *  
 * @author Layne Bennett
 *
 */

/**
 * 
 * This class implements selection sort.   
 *
 */

public class SelectionSorter extends AbstractSorter
{
	// Other private instance vars if needed...
	
	/**
	 * Constructor takes an array of points.  It invokes the superclass constructor, and also 
	 * set the instance variables algorithm in the superclass.
	 *  
	 * @param pts  
	 */
	public SelectionSorter(Point[] pts)  
	{
		// Call superclass constructor
		super(pts);  
		
		this.algorithm = "SelectionSort";  // Set algo name to SelectionSort
		
	}	

	
	/** 
	 * Apply selection sort on the array points[] of the parent class AbstractSorter.  
	 * 
	 */
	@Override 
	public void sort()
	{
		for(int i = 0; i < points.length - 1; i++) {
			int minIndex = i;  // Assume current element is smallest
			
			for(int j = i + 1; j < points.length; j++) {
				// Compare and find the minimum element
				if(pointComparator.compare(points[j], points[minIndex]) < 0) {
					minIndex = j;
				}
			}
			
			// Swap if minIndex is not the current index
			if(i != minIndex) {
				swap(minIndex, i);
			}
			
		}
	}	
}
