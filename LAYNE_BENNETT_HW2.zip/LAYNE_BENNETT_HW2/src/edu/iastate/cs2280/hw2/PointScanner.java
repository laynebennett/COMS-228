package edu.iastate.cs2280.hw2;

/**
 * 
 * @author Layne Bennett
 *
 */

import java.io.FileNotFoundException;
import java.util.InputMismatchException;
import java.lang.IllegalArgumentException;
import java.util.Scanner;
import java.io.File;
import java.io.PrintWriter;
import java.io.FileWriter;
import java.io.IOException;

/**
 * 
 * This class sorts all the points in an array of 2D points to determine a
 * reference point whose x and y coordinates are respectively the medians of the
 * x and y coordinates of the original points.
 * 
 * It records the employed sorting algorithm as well as the sorting time for
 * comparison.
 *
 */
public class PointScanner {
	private Point[] points; // created array of points

	private Point medianCoordinatePoint; 
	private Algorithm sortingAlgorithm; 

	protected long scanTime; // time for sorting in nanoseconds

	private String outputFileName = "MCP.txt"; //file name output

	/**
	 * Constructor to initialize points array and algorithm.
	 * 
	 * @param pts input array of points
	 * @throws IllegalArgumentException if pts == null or pts.length == 0.
	 */
	public PointScanner(Point[] pts, Algorithm algo) throws IllegalArgumentException {

		sortingAlgorithm = algo;

		if (pts == null || pts.length == 0) {
			throw new IllegalArgumentException("pts == null or pts.length == 0.");
		}

		points = new Point[pts.length]; // copy of points array
		for (int i = 0; i < pts.length; i++) {
			points[i] = pts[i];
		}
	}

	/**
	 * Constructor to read points from a file.
	 * 
	 * @param inputFileName
	 * @throws FileNotFoundException
	 * @throws InputMismatchException if file has an odd number of integers
	 */
	protected PointScanner(String inputFileName, Algorithm algo) throws FileNotFoundException, InputMismatchException {
		sortingAlgorithm = algo;
		File file = new File(inputFileName);

		try {
			Scanner scnr = new Scanner(file);
			int pointCount = 0;

			// First pass: count points
			while (scnr.hasNextInt()) {
				scnr.nextInt(); // Skip x
				if (scnr.hasNextInt()) {
					scnr.nextInt(); // Skip y
					pointCount++;
				} else {
					scnr.close();
					throw new InputMismatchException("Odd number of integers in the file.");
				}

			}
			scnr.close();

			points = new Point[pointCount]; // Initialize points array

			// Second pass: populate points array
			scnr = new Scanner(file);
			int i = 0;
			while (scnr.hasNextInt()) {
				int tempX = scnr.nextInt();
				int tempY = scnr.nextInt();
				points[i] = new Point(tempX, tempY);
				i++;
			}
			scnr.close();

		} catch (FileNotFoundException e) {
			throw new FileNotFoundException("File not found: " + inputFileName);
		} catch (InputMismatchException e) {
			throw new InputMismatchException("Invalid file format. " + e.getMessage());
		}
	}

	/**
	 * Carry out two rounds of sorting to find the median x and y coordinates.
	 */
	public void scan() {
		AbstractSorter aSorter;

		// Choose the appropriate sorter based on the algorithm
		switch (sortingAlgorithm) {
		case SelectionSort:
			aSorter = new SelectionSorter(points);
			break;
		case InsertionSort:
			aSorter = new InsertionSorter(points);
			break;
		case MergeSort:
			aSorter = new MergeSorter(points);
			break;
		case QuickSort:
			aSorter = new QuickSorter(points);
			break;
		default:
			throw new IllegalArgumentException("Invalid sorting algorithm");
		}

		scanTime = 0; // Reset scan time

		// Sort by x-coordinate
		aSorter.setComparator(0);
		long startTime = System.nanoTime();
		aSorter.sort();
		long endTime = System.nanoTime();
		scanTime += (endTime - startTime); // Accumulate time

		int xMed = aSorter.getMedian().getX(); // Get median x-coordinate

		// Sort by y-coordinate
		aSorter.setComparator(1);
		startTime = System.nanoTime();
		aSorter.sort();
		endTime = System.nanoTime();
		scanTime += (endTime - startTime); // Accumulate time

		int yMed = aSorter.getMedian().getY(); // Get median y-coordinate

		medianCoordinatePoint = new Point(xMed, yMed); // Create median point
	}

	/**
	 * Outputs performance statistics: "<sorting algorithm> <size> <time>"
	 * @throws IOException 
	 */
	public String stats() throws IOException {
		try {
			String algorithmName = sortingAlgorithm.toString();
			int size = points.length;
			long time = scanTime;
			this.writeMCPToFile();
			return String.format("%-15s %d %d", algorithmName, size, time); // Format output
		} catch (IllegalArgumentException e) {
			System.out.println("No Timer Value");
			return "No Timer Value";
		}
	}

	/**
	 * Returns MCP in the format: "MCP: (x, y)"
	 */
	@Override
	public String toString() {
		return "MCP: (" + medianCoordinatePoint.getX() + ", " + medianCoordinatePoint.getY() + ")";
	}

	/**
	 * Writes the MCP to a file in the format: "MCP: (x, y)"
	 * @throws IOException 
	 */
	public void writeMCPToFile() throws IOException {
		try {
			FileWriter fileWriter = new FileWriter(outputFileName, true); // true means append mode
			PrintWriter writer = new PrintWriter(fileWriter);

			writer.println(this.toString());// Write MCP to file
			writer.close();

		} catch (FileNotFoundException e) {

			throw new FileNotFoundException("File not found: " + outputFileName);
		}
	}
	
	/**
	 * returns points array in point scanner object
	 * @return points
	 */
	public Point[] getPoints() {
		return points;
	}
}
